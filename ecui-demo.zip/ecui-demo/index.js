(function () {
ecui.esr.onready = function () {
    return {
        main: 'main',
        view: function () {},
        onbeforerequest: function () {
        },
        onbeforerender: function (context) {
        },
        onafterrender: function () {
        }
    };
};
ecui.esr.addRoute('index', {
    model: [''],
    main: 'main',
    view: function () {
        ecui.$('main').innerHTML = '<div><a href="#/demo/childdemo/childdemo">go-childdemo</a></div>';
    },
    onbeforerequest: function () {
    },
    onbeforerender: function (context) {
    },
    onafterrender: function () {
    }
});
}());
