ecui.esr.addRoute('childdemo', {
    model: [''],
    main: 'main',
    view: 'demo_childdemo',
    onbeforerequest: function (context) {
    },
    onbeforerender: function (context) {
    },
    onafterrender: function () {
        // ecui.get('button_demo').onclick = function () {
        //     ecui.esr.redirect('/demo/demo');
        // };
    },
});
