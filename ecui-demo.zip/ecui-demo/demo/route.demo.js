ecui.esr.addRoute('demo', {
    model: [''],
    main: 'main',
    view: 'demo_demo',
    onbeforerequest: function (context) {
    },
    onbeforerender: function (context) {
    },
    onafterrender: function () {
        // ecui.get('button_demo').onclick = function () {
        //     ecui.esr.redirect('/demo/childdemo');
        // };
    },
});
